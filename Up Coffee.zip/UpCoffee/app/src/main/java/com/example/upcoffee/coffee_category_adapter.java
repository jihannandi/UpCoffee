package com.example.upcoffee;

import android.content.Context;
import android.graphics.Color;
import android.graphics.PorterDuff;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.card.MaterialCardView;

import java.util.List;

public class coffee_category_adapter extends RecyclerView.Adapter<coffee_category_adapter.category_holder> {

    List<coffee_category> data;
    Context context;
    int selectedItem = 0;

    OnCategoryClick onCategoryClick;

    public interface OnCategoryClick {
        void onClick(int pos);
    }
    public coffee_category_adapter(List<coffee_category> data, Context context, OnCategoryClick onCategoryClick) {
        this.data = data;
        this.context = context;
        this.onCategoryClick = onCategoryClick;
    }

    @NonNull
    @Override
    public category_holder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater layoutInflater = LayoutInflater.from(context);
        View view = layoutInflater.inflate(R.layout.category_holder,parent,false);
        return new category_holder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull category_holder holder, int position) {
        holder.image.setImageResource(data.get(position).getImage());
        holder.title.setText(data.get(position).getName());
        if (selectedItem == position){
            holder.View.animate().scaleX(1.1f);
            holder.View.animate().scaleY(1.1f);
            holder.View.setStrokeWidth(2);
            holder.title.setTextColor(context.getColor(R.color.brown));
            holder.image.setImageResource(data.get(position).getImage());
        } else {
            holder.View.animate().scaleX(1f);
            holder.View.animate().scaleY(1f);
            holder.title.setTextColor(context.getColor(R.color.black));
            holder.image.setImageResource(data.get(position).getImage());
            holder.View.setStrokeWidth(0);
        }
    }

    @Override
    public int getItemCount() {
        return data.size();
    }

    class category_holder extends RecyclerView.ViewHolder{
        TextView title;
        ImageView image;
        MaterialCardView View;

        public category_holder (View holder){
            super(holder);
            title = holder.findViewById(R.id.coffee_title);
            image = holder.findViewById(R.id.coffee_img);
            View = holder.findViewById(R.id.card_view);

            View.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    selectedItem = getAdapterPosition();
                    //reset items, so that color changes when we click on card
                    if (onCategoryClick != null){
                        onCategoryClick.onClick(getAdapterPosition());
                    }
                    notifyDataSetChanged();
                }
            });
        }
    }
}
