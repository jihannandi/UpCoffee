package com.example.upcoffee;

import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    RecyclerView recyclerCategories;
    RecyclerView recyclerItems;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        recyclerCategories = findViewById(R.id.recycler_categories);
        recyclerItems = findViewById(R.id.recycler_coffee);

        setCategories();
        setcoffee_item(0);

    }

    private void setCategories() {
        List<coffee_category> data = new ArrayList<>();

        coffee_category coffeeCategory = new coffee_category("Hot Coffee",R.drawable.hot_coffee);
        coffee_category coffeeCategory1 = new coffee_category("Ice Coffee",R.drawable.ice_coffee);

        data.add(coffeeCategory);
        data.add(coffeeCategory1);


        coffee_category_adapter coffee_category_adapter = new coffee_category_adapter(data, MainActivity.this, new coffee_category_adapter.OnCategoryClick() {
            @Override
            public void onClick(int pos) { setcoffee_item(pos); }
        });

        recyclerCategories.setLayoutManager(new LinearLayoutManager(MainActivity.this, RecyclerView.HORIZONTAL,false));
        recyclerCategories.setAdapter(coffee_category_adapter);
        coffee_category_adapter.notifyDataSetChanged();
    }

    private void setcoffee_item(int pos){
        List<coffee_item> coffee_items = new ArrayList<>();
        switch (pos) {
            case 1:
                coffee_item coffee_item = new coffee_item("Hazelnut Latte",4.5f,14,R.drawable.ice_coffee1);
                coffee_item coffee_item1 = new coffee_item("Moccacino",5f,14,R.drawable.ice_coffee2);
                coffee_item coffee_item2 = new coffee_item("Vanila Latte",5f,14,R.drawable.ice_coffee3);
                coffee_item coffee_item3 = new coffee_item("Cappucino",4f,14,R.drawable.ice_coffee4);

                coffee_items.add(coffee_item);
                coffee_items.add(coffee_item1);
                coffee_items.add(coffee_item2);
                coffee_items.add(coffee_item3);
                break;
            case 0:
                coffee_item coffee_item4 = new coffee_item("Americano",4.5f,11,R.drawable.hot_coffee1);
                coffee_item coffee_item5 = new coffee_item("Coffee Latte",5f,12,R.drawable.hot_coffee2);
                coffee_item coffee_item6 = new coffee_item("Caramel Latte",4f,12,R.drawable.hot_coffee3);
                coffee_item coffee_item7= new coffee_item("Flat White",3.5f,14,R.drawable.hot_coffee4);

                coffee_items.add(coffee_item4);
                coffee_items.add(coffee_item5);
                coffee_items.add(coffee_item6);
                coffee_items.add(coffee_item7);
                break;
        }

        coffee_adapter coffee_adapter = new coffee_adapter (coffee_items);
        recyclerItems.setLayoutManager(new LinearLayoutManager(MainActivity.this,RecyclerView.HORIZONTAL,false));

        recyclerItems.setAdapter(coffee_adapter);
    }
}