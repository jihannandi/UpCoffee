package com.example.upcoffee;

import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RatingBar;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class coffee_adapter extends RecyclerView.Adapter<coffee_adapter.coffee_holder> {

    List<coffee_item> data;
    int selectedItem = 0;

    public coffee_adapter(List<coffee_item> data){
        this.data = data;
    }
    @NonNull
    @Override
    public coffee_holder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        LayoutInflater layoutInflater = LayoutInflater.from(parent.getContext());
        View view = layoutInflater.inflate(R.layout.coffee_holder, parent, false);

        return new coffee_holder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull coffee_holder holder, int position) {
        holder.price.setText(String.format("$%d",data.get(position).getPrice()));
        holder.image.setImageResource(data.get(position).getImage());
        holder.title.setText(data.get(position).getName());
        holder.ratingBar.setRating(data.get(position).getRating());

        if (selectedItem == position){
            holder.cardView.animate().scaleX(1.1f);
            holder.cardView.animate().scaleY(1.1f);
            holder.title.setTextColor(Color.WHITE);
            holder.price.setTextColor(Color.WHITE);
            holder.llBackground.setBackgroundResource(R.drawable.splash);
        }else {
            holder.cardView.animate().scaleX(1f);
            holder.cardView.animate().scaleY(1f);
            holder.title.setTextColor(Color.BLACK);
            holder.price.setTextColor(Color.BLACK);
            holder.llBackground.setBackgroundResource(R.color.white);
        }
    }

    @Override
    public int getItemCount() {
        return data.size();
    }

    class coffee_holder extends RecyclerView.ViewHolder {
        RatingBar ratingBar;
        ImageView image;
        TextView title;
        TextView price;
        LinearLayout llBackground;
        CardView cardView;
        public coffee_holder(View holder) {
            super(holder);
            ratingBar = holder.findViewById(R.id.rating);
            title = holder.findViewById(R.id.coffee_title);
            image = holder.findViewById(R.id.coffee_img);
            price = holder.findViewById(R.id.txt_price);
            cardView = holder.findViewById(R.id.coffee_background);
            llBackground = holder.findViewById(R.id.ll_background);

            cardView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    selectedItem = getAdapterPosition();
                    notifyDataSetChanged();
                }
            });
        }
    }
}
